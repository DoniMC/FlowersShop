package com.dolghun.musicshop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ViewFlipper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private TextView quantityTextView;
    private Spinner spinner;
    private List spinnerArrayList;
    private TextView priceTextView;
    private ImageView goodsImageView;
    private EditText userNameEditText;
    private ViewFlipper viewFlipper;
    ArrayAdapter spinnerAdapter;
    HashMap goodsMap;
    private String goodsName;
    private Double price;
    int quantity = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        quantityTextView = findViewById(R.id.quantityTextView);
        priceTextView = findViewById(R.id.priceTextView);
        goodsImageView = findViewById(R.id.goodsImageView);
        userNameEditText = findViewById(R.id.nameEditText);
        viewFlipper = findViewById(R.id.v_flipper);

        int images[] = {R.drawable.pion1, R.drawable.pion2};

        //for loop

        for (int image : images) {
            flipperImages(image);
        }

        createSpinner();
        createMap();

    }

    public void flipperImages(int image) {
        ImageView imageView = new ImageView(this);
        imageView.setBackgroundResource(image);

        viewFlipper.addView(imageView);
        viewFlipper.setFlipInterval(4000);
        viewFlipper.setAutoStart(true);

        //animation
        viewFlipper.setInAnimation(this, android.R.anim.slide_in_left);
        viewFlipper.setOutAnimation(this, android.R.anim.slide_out_right);
    }

    void createSpinner() {
        spinner = findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(this);
        spinnerArrayList = new ArrayList();
        spinnerArrayList.add(getString(R.string.monobuckets));
        spinnerArrayList.add(getString(R.string.the_brides_bouquet));
        spinnerArrayList.add(getString(R.string.valentine));
        spinnerArrayList.add(getString(R.string.peonies_by_the_piece));
        spinnerArrayList.add(getString(R.string.flowers_in_a_box));
        spinnerArrayList.add(getString(R.string.flowers_in_a_bag));
        spinnerAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, spinnerArrayList);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(spinnerAdapter);
    }

    void createMap() {
        goodsMap = new HashMap();
        goodsMap.put("Монобукеты", 2290.0);
        goodsMap.put("Букет невесты", 4290.0);
        goodsMap.put("Валентинки", 3440.0);
        goodsMap.put("Пионы поштучно", 300.0);
        goodsMap.put("Цветы в коробке", 1850.0);
        goodsMap.put("Цветы в сумке", 1850.0);
    }

    public void increaseQuantity(View view) {
        quantity += 1;
        quantityTextView.setText("" + quantity);
        priceTextView.setText("" + quantity * price);
    }

    public void decreaseQuantity(View view) {
        quantity -= 1;
        if (quantity < 0) {
            quantity = 0;
        } else {
            quantityTextView.setText("" + quantity);
            priceTextView.setText("" + quantity * price);
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        goodsName = spinner.getSelectedItem().toString();
        price = (double) goodsMap.get(goodsName);
        priceTextView.setText("" + quantity * price);

        switch (goodsName) {
            case "Монобукеты":
                goodsImageView.setImageResource(R.drawable.monobuckets);
                break;
            case "Букет невесты":
                goodsImageView.setImageResource(R.drawable.the_brides_bouquet);
                break;
            case "Валентинки":
                goodsImageView.setImageResource(R.drawable.valentine);
                break;
            case "Пионы поштучно":
                goodsImageView.setImageResource(R.drawable.peonies_by_the_piece);
                break;
            case "Цветы в коробке":
                goodsImageView.setImageResource(R.drawable.flowers_in_a_box);
                break;
            case "Цветы в сумке":
                goodsImageView.setImageResource(R.drawable.flowers_in_a_bag);
                break;
            default:
                goodsImageView.setImageResource(R.drawable.flowers_in_a_bag);
                break;
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    public void addToCart(View view) {
        Order order = new Order();
        order.setUserName(userNameEditText.getText().toString());
        order.setGoodsName(goodsName);
        order.setQuantity(quantity);
        order.setPrice(price);
        order.setOrderPrice(quantity * price);

        Intent orderIntent = new Intent(MainActivity.this, OrderActivity.class);
        orderIntent.putExtra("userName", order.getUserName());
        orderIntent.putExtra("goodsName", order.getGoodsName());
        orderIntent.putExtra("quantity", order.getQuantity());
        orderIntent.putExtra("price", order.getPrice());
        orderIntent.putExtra("orderPrice", order.getOrderPrice());
        startActivity(orderIntent);
    }
}